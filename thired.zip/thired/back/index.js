const cors = require('cors');
const express = require('express');
const mongoose = require('mongoose');
const FormDataModel = require('./models/FormData');


const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect('mongodb//127.0.1:27017/sonam');

app.post('/register',(req, res)=>{
    //to post / insert data into database

    const {email,subject} = req.body;
    FormDataModel.findOne({email: email})
    .then(user => {
        if(user){
            res.json("Already registred")
        }
        else{
            FormDataModel.create(req.body)
            .then(log_form => res.json(log_form))
            .catch(err => res.json(err))
        }

    })

})

app.post('/login',(req, res)=>{
    //to find record form the database
    const {email, password} =req.body;
    FormDataModel.findOne({email:email})
    .then(user => {
        if (user){
            //if user found then these 2 cases
            if(user.password === password){
                res.json("success");
            }
            else{
                res.json("Worng password");
            }
        }
        //if user not found then
        else{
            res.json("Wrong password");
        }
    })
})

app.listen(3001,() =>{
 console.log("Server listining on http://127.0.0.1:3001");

});