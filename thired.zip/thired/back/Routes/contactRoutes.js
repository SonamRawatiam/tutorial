const express = require("express");
const router = express.Router();
const Contact = require("../models/Contact");

// @route   POST /contact
// @desc    Save form data to MongoDB
router.post("/", async (req, res) => {
  try {
    const { name, email, password, message } = req.body;

    if (!name || !email || !password || !message) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const newContact = new Contact({ name, email, password, message });
    await newContact.save();

    res.status(201).json({ message: "Message sent successfully!" });
  } catch (error) {
    console.error("Error saving contact:", error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
