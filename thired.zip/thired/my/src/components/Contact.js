import React, { useState } from "react";
import axios from "axios";
import "./ContactForm.css"; // Import CSS file

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    message: "",
  });

  const [errors, setErrors] = useState({});
  const [responseMessage, setResponseMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    let newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email))
      newErrors.email = "Valid email is required";
    if (!formData.password.trim()) newErrors.password = "Password is required"; // Fixed key
    if (!formData.message.trim()) newErrors.message = "Message is required";
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formErrors = validateForm();
    if (Object.keys(formErrors).length === 0) {
      try {
        const response = await axios.post("http://localhost:5000/contact", formData); // Fixed API URL
        setResponseMessage(response.data.message);
        setFormData({ name: "", email: "", password: "", message: "" });
        setErrors({});
      } catch (error) {
        setResponseMessage(error.response?.data?.message || "Error sending message");
      }
    } else {
      setErrors(formErrors);
    }
  };

  return (
    <div className="contact-container">
      <h2>Contact Us</h2>
      {responseMessage && <p className="response">{responseMessage}</p>}
      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label>Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
          />
          {errors.name && <span className="error">{errors.name}</span>}
        </div>

        <div className="input-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          {errors.email && <span className="error">{errors.email}</span>}
        </div>

        <div className="input-group">
          <label>Password</label>
          <input
            type="password" // Changed to password type
            name="password"
            value={formData.password} // Fixed incorrect field
            onChange={handleChange}
          />
          {errors.password && <span className="error">{errors.password}</span>} 
        </div>

        <div className="input-group">
          <label>Message</label>
          <textarea
            name="message"
            value={formData.message}
            onChange={handleChange}
          ></textarea>
          {errors.message && <span className="error">{errors.message}</span>}
        </div>

        <button type="submit">Send Message</button>
      </form>
    </div>
  );
};

export default Contact;
