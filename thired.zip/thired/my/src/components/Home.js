import React from "react";
import "./Home.css"; // Separate styles
import Footerhome from "../components/Footerhome";

const Home = () => {
  return (
    <section className="home-section">
      <div className="container">
        <div className="home-content">
        <h2 style={{ color: "white", fontSize:"40px" }}>Mobile App Development</h2>
        <p style={{ fontSize: "20px" }}>
            Join us in the exciting world of programming and turn your ideas into
            reality. Unlock the world of endless possibilities—learn to code and
            shape the digital future with us.
          </p>
          <div className="buttons">
            <a href="#" className="join">Join Now</a>
            <a href="#" className="learn">Learn More</a>
          </div>
        </div>
        <div className="img">
          <img
            src="https://www.addevice.io/storage/ckeditor/uploads/images/65f82dcd3866a_ai.in.mobile.app.development.1920.1080.png"
            alt="Illustration of mobile app development"
          />
        </div>
        
      </div>
      <Footerhome  />
    </section>
    
  );
};

export default Home;
