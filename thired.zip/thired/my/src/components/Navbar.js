import React from "react";
import { Link } from "react-router-dom";
import { FaHome, FaInfoCircle, FaEnvelope } from "react-icons/fa";
import { MdMiscellaneousServices } from "react-icons/md";
import { MdRoundaboutLeft } from "react-icons/md";

const Navbar = () => {
  return (
    
    <nav style={{ padding: "16px", background: "#333", color: "white" }}>
      <ul style={{ display: "flex", gap: "15px", listStyle: "none" }}>
        <li>
          <Link to="/" style={{ color: "white",fontSize:"20px", textDecoration: "none" }}>
          <FaHome /> Home
          </Link>
        </li>
        <li>
          <Link to="/contact" style={{ color: "white",fontSize:"20px", textDecoration: "none" }}>
          <FaEnvelope  /> Contact
          </Link>
        </li>
        <li>
          <Link to="/ServicesPage" style={{ color: "white",fontSize:"20px", textDecoration: "none" }}>
          <MdMiscellaneousServices />Services
          </Link>
        </li>
        <li>
          <Link to="/about" style={{ color: "white",fontSize:"20px", textDecoration: "none" }}>
          <MdRoundaboutLeft /> About
          </Link>
        </li>
        <li>
        <div style={{ textAlign: "left" }}> 
      <button style={{ padding: "10px 10px", fontSize: "18px",left:"400px", marginLeft: "600px",width:"100px"  }}>Click Me</button>
    </div>
    </li>
      </ul>
    </nav>
  );
};

export default Navbar;
