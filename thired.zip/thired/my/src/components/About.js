import React from "react";
import "./About.css";
import Footer from "../components/Footer";




const teamMembers = [
  {
    name: "Jane Doe",
    role: "CEO & Founder",
    description: "Some text that describes me lorem ipsum ipsum lorem.",
    email: "jane@example.com",
    imgSrc: "/team1.jpg",
  },
  {
    name: "Mike Ross",
    role: "Art Director",
    description: "Some text that describes me lorem ipsum ipsum lorem.",
    email: "mike@example.com",
    imgSrc: "/team2.jpg",
  },
  {
    name: "John Doe",
    role: "Designer",
    description: "Some text that describes me lorem ipsum ipsum lorem.",
    email: "john@example.com",
    imgSrc: "/team3.jpg",
  },
];

const TeamCard = ({ member }) => {
  return (
    <div className="column">
      <div className="card">
        <img src={member.imgSrc} alt={member.name} className="image" />
        <div className="container">
          <h2>{member.name}</h2>
          <p className="title">{member.role}</p>
          <p>{member.description}</p>
          <p>{member.email}</p>
          <button className="button">Contact</button>
        </div>
      </div>
    </div>
  );
};

const About = () => {
  return (
    <div>
      <div className="about-section">
        <h1>About Us</h1>
        <p>Some text about who we are and what we do.</p>
        <p>Resize the browser window to see that this page is responsive.</p>
      </div>
      <h2 className="text-center">Our Team</h2>
      <div className="row">
        {teamMembers.map((member, index) => (
          <TeamCard key={index} member={member} />
        ))}
      </div>
      <Footer  />

    </div>
  );
};

export default About;