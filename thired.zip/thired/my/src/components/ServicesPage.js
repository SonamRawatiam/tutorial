import React from "react";
import "@fortawesome/fontawesome-free/css/all.min.css"; // Import FontAwesome for icons
import "./Services.css"; // Import the CSS file for styling

const servicesData = [
  { icon: "fa-solid fa-hammer", title: "Carpentry", description: "High-quality carpentry services for all your woodwork needs." },
  { icon: "fa-solid fa-paint-brush", title: "Painting", description: "Professional painting services for homes and offices." },
  { icon: "fa-solid fa-wrench", title: "Repair & Maintenance", description: "Expert repair and maintenance services for your property." },
  { icon: "fa-solid fa-truck-pickup", title: "Transport Services", description: "Fast and reliable transport and moving services." },
  { icon: "fa-solid fa-broom", title: "Cleaning Services", description: "Efficient cleaning services for homes and businesses." },
  { icon: "fa-solid fa-plug", title: "Electrical Work", description: "Certified electrical work for homes and offices." }
];

const Services = () => {
  return (
    <section className="services">
      <div className="row">
        <h2 className="section-heading">Our Services</h2>
      </div>
      <div className="row">
        {servicesData.map((service, index) => (
          <div key={index} className="column">
            <div className="card">
              <div className="icon-wrapper">
                <i className={service.icon} aria-hidden="true"></i>
              </div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Services;
